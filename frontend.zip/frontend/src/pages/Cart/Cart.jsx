import React from 'react'
import './Cart.css'
const Card = () => {
  return (
    <div>
      
    </div>
  )
}

export default Card
